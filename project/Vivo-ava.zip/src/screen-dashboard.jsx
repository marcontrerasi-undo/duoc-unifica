// src/screen-dashboard.jsx — Dashboard unificado → window.DashboardScreen
const { useState: useStateDash } = React;

function DashboardScreen({ student, onNavigate, onOpenSearch, onCourse, unread, onOpenNotifs }) {
  const { Icon, Card, Badge, Button, CourseGlyph, Progress } = window;
  const { COURSES, CALENDAR, QUICK_ACTIONS } = window.DATA;

  const hora = new Date().getHours();
  const saludo = hora < 12 ? 'Buenos días' : hora < 19 ? 'Buenas tardes' : 'Buenas noches';

  return (
    <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
      {/* Saludo */}
      <header className="anim-fade-up flex flex-wrap items-end justify-between gap-4 mb-6">
        <div>
          <p className="text-muted font-medium text-[14px]">{saludo},</p>
          <h1 className="font-display font-extrabold tracking-tight text-ink text-[clamp(1.7rem,4vw,2.4rem)] leading-tight">{student.primerNombre} 👋</h1>
          <p className="text-faint text-[13.5px] mt-1 font-medium">{student.carrera} · {student.semestre} · {student.sede}</p>
        </div>
        <div className="flex items-center gap-2">
          <StatChip icon="trending" label="Avance carrera" value={`${student.avance}%`} tone="primary" />
          <StatChip icon="award" label="Promedio" value="6,0" tone="ok" />
          <StatChip icon="clock" label="Pendientes" value="4" tone="medium" />
        </div>
      </header>

      {/* Búsqueda global */}
      <button data-tour="tour-search" onClick={onOpenSearch}
        className="anim-fade-up w-full flex items-center gap-3 h-14 px-5 rounded-2xl bg-surface border border-line shadow-card text-left hover:shadow-float hover:border-primary/40 transition-all duration-300 mb-7 group"
        style={{ animationDelay: '.05s' }}>
        <Icon name="search" size={21} className="text-primary" />
        <span className="text-faint text-[15px] font-medium flex-1">Busca cursos, trámites, recursos o personas…</span>
        <span className="hidden sm:flex items-center gap-1 text-[12px] font-bold text-faint px-2 py-1 rounded-lg bg-surface-2 border border-line">⌘K</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Columna principal */}
        <div className="lg:col-span-2 space-y-6">
          {/* Cursos */}
          <section data-tour="tour-courses" className="anim-fade-up" style={{ animationDelay: '.1s' }}>
            <SectionHead icon="book" title="Mis cursos" sub="Semestre en curso" action="Ver todos" onAction={() => onNavigate('cursos')} />
            <div className="flex flex-col gap-3 mt-4">
              {COURSES.map((c, i) => {
                const a = c.asistencia || { minimo: 75, asistidas: 0, inasistencias: 0 };
                const real = a.asistidas + a.inasistencias;
                const aPct = real ? Math.round((a.asistidas / real) * 100) : 100;
                const aColor = aPct < a.minimo ? 'var(--high)' : aPct < a.minimo + 8 ? 'var(--medium)' : 'var(--ok)';
                return (
                <Card key={c.id} hover pad={false} onClick={() => onCourse(c.id)} className="p-4 sm:p-5 group anim-fade-up" style={{ animationDelay: `${.12 + i * .04}s` }}>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                    {/* Info */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[11.5px] font-bold tracking-wide text-faint">{c.sigla} · {c.seccion}</span>
                      </div>
                      <h3 className="font-display font-bold text-ink text-[16px] sm:text-[17px] leading-snug mt-1 group-hover:text-primary transition-colors">{c.nombre}</h3>
                      <div className="text-faint text-[12.5px] mt-1.5 flex items-center gap-x-4 gap-y-1 flex-wrap">
                        <span className="flex items-center gap-1.5"><Icon name="user" size={13} /> {c.docente}</span>
                        <span className="flex items-center gap-1.5"><Icon name="calendar" size={13} /> {c.proxima}</span>
                      </div>
                    </div>
                    {/* Progreso + Asistencia */}
                    <div className="sm:w-[230px] shrink-0 space-y-2.5">
                      <div>
                        <div className="flex items-center justify-between text-[12px] font-semibold text-muted mb-1.5">
                          <span>Progreso del curso</span><span style={{ color: 'var(--ok)' }}>{c.progreso}%</span>
                        </div>
                        <Progress value={c.progreso} color="var(--ok)" />
                      </div>
                      <div>
                        <div className="flex items-center justify-between text-[12px] font-semibold text-muted mb-1.5">
                          <span>Asistencia</span><span style={{ color: aColor }}>{aPct}%</span>
                        </div>
                        <Progress value={aPct} color={aColor} />
                      </div>
                    </div>
                    <Icon name="chevronRight" size={20} className="text-faint shrink-0 hidden sm:block group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </Card>
                );
              })}
            </div>
          </section>

          {/* Trámites rápidos */}
          <section className="anim-fade-up" style={{ animationDelay: '.18s' }}>
            <SectionHead icon="grid" title="Trámites rápidos" sub="Lo administrativo, sin salir de aquí" action="Centro de ayuda" onAction={() => onNavigate('ayuda')} />
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4">
              {QUICK_ACTIONS.map((q) => (
                <button key={q.id} onClick={() => onNavigate('ayuda')}
                  className={`relative flex flex-col gap-2.5 p-4 rounded-2xl border text-left transition-all duration-300 active:scale-[.98] hover:-translate-y-0.5 focus-ring ${q.destacado ? 'bg-primary text-[color:var(--on-primary)] border-transparent shadow-card' : 'bg-surface border-line hover:shadow-card'}`}
                  style={{ minHeight: 44 }}>
                  <div className="grid place-items-center rounded-xl" style={{ width: 38, height: 38, background: q.destacado ? 'color-mix(in srgb, var(--on-primary) 15%, transparent)' : 'var(--primary-soft)' }}>
                    <Icon name={q.icon} size={19} className={q.destacado ? 'text-[color:var(--on-primary)]' : 'text-primary'} />
                  </div>
                  <div>
                    <div className="text-[10.5px] font-bold tracking-wide uppercase" style={{ color: q.destacado ? 'color-mix(in srgb, var(--on-primary) 70%, transparent)' : 'var(--text-faint)' }}>{q.categoria}</div>
                    <div className={`text-[13.5px] font-semibold leading-snug mt-0.5 ${q.destacado ? 'text-[color:var(--on-primary)]' : 'text-ink'}`}>{q.label}</div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        </div>

        {/* Columna lateral */}
        <div className="space-y-6">
          {/* Calendario unificado */}
          <section data-tour="tour-calendar" className="anim-fade-up" style={{ animationDelay: '.14s' }}>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-display font-bold text-ink text-[17px] flex items-center gap-2"><Icon name="calendar" size={18} className="text-primary" /> Agenda</h2>
              <span className="text-[12px] font-semibold text-faint">Junio 2026</span>
            </div>
            <Card pad={false} className="p-4">
              <div className="space-y-4">
                {CALENDAR.map((day) => (
                  <div key={day.id}>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-[10.5px] font-bold tracking-wide px-2 py-0.5 rounded-md ${day.dia === 'HOY' ? 'bg-primary text-[color:var(--on-primary)]' : 'bg-surface-2 text-faint'}`}>{day.dia}</span>
                      <span className="text-[12px] font-semibold text-muted">{day.fecha}</span>
                    </div>
                    <div className="space-y-2 pl-1">
                      {day.items.map((it, idx) => (
                        <div key={idx} className="flex items-start gap-3">
                          <div className="text-[12px] font-bold text-muted tabular-nums pt-0.5 w-11 shrink-0">{it.hora}</div>
                          <div className="relative pl-3.5 flex-1 min-w-0">
                            <span className="absolute left-0 top-1 bottom-1 w-1 rounded-full" style={{ background: it.color }}></span>
                            <p className="text-ink font-semibold text-[13px] leading-snug">{it.titulo}</p>
                            <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                              <span className="text-faint text-[11.5px] font-medium">{it.lugar}</span>
                              {it.alerta && <Badge tone={it.tipo === 'evaluacion' ? 'high' : 'medium'}>{it.alerta}</Badge>}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </section>
        </div>
      </div>
    </div>
  );
}

function StatChip({ icon, label, value, tone }) {
  const { Icon } = window;
  const colors = { primary: 'var(--primary)', ok: 'var(--ok)', medium: 'var(--medium)' };
  return (
    <div className="hidden sm:flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-surface border border-line shadow-card">
      <div className="grid place-items-center rounded-lg" style={{ width: 32, height: 32, background: `color-mix(in srgb, ${colors[tone]} 13%, transparent)` }}>
        <Icon name={icon} size={16} style={{ color: colors[tone] }} />
      </div>
      <div className="leading-none">
        <div className="text-[16px] font-display font-extrabold text-ink">{value}</div>
        <div className="text-[10.5px] font-semibold text-faint mt-0.5 whitespace-nowrap">{label}</div>
      </div>
    </div>
  );
}

function SectionHead({ icon, title, sub, action, onAction }) {
  const { Icon } = window;
  return (
    <div className="flex items-end justify-between gap-3">
      <div>
        <h2 className="font-display font-bold text-ink text-[18px] flex items-center gap-2"><Icon name={icon} size={19} className="text-primary" /> {title}</h2>
        {sub && <p className="text-faint text-[12.5px] font-medium mt-0.5 ml-7">{sub}</p>}
      </div>
      {action && <button onClick={onAction} className="text-[13px] font-bold text-primary inline-flex items-center gap-1 hover:gap-1.5 transition-all shrink-0">{action} <Icon name="arrowRight" size={14} /></button>}
    </div>
  );
}

window.DashboardScreen = DashboardScreen;
