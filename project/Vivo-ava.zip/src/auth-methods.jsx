// src/auth-methods.jsx — Flujos reales de acceso: Biometría (huella) y Código QR
// Exporta window.BiometricSheet y window.QRSheet
const { useState: useStateAuth, useEffect: useEffectAuth, useRef: useRefAuth } = React;

/* ============================================================
   BIOMETRÍA — mantener presionado el sensor → lectura → verificación
   ============================================================ */
function BiometricSheet({ open, onClose, onLogin }) {
  const { Sheet, Icon } = window;
  // 'idle' | 'scanning' | 'success' | 'error'
  const [phase, setPhase] = useStateAuth('idle');
  const [pct, setPct] = useStateAuth(0);
  const rafRef = useRefAuth(null);
  const startRef = useRefAuth(0);
  const DURATION = 1500;

  // Reinicia el estado cada vez que se abre
  useEffectAuth(() => {
    if (open) { setPhase('idle'); setPct(0); }
    return () => cancelAnimationFrame(rafRef.current);
  }, [open]);

  const stopRAF = () => { cancelAnimationFrame(rafRef.current); rafRef.current = null; };

  const tick = (now) => {
    const elapsed = now - startRef.current;
    const p = Math.min(1, elapsed / DURATION);
    setPct(p);
    if (p >= 1) {
      stopRAF();
      setPhase('success');
      setTimeout(() => onLogin && onLogin(), 1050);
    } else {
      rafRef.current = requestAnimationFrame(tick);
    }
  };

  const beginScan = () => {
    if (phase === 'success' || phase === 'scanning') return;
    setPhase('scanning');
    startRef.current = performance.now();
    rafRef.current = requestAnimationFrame(tick);
  };

  // Soltar antes de completar = lectura incompleta
  const releaseScan = () => {
    if (phase !== 'scanning') return;
    stopRAF();
    setPhase('error');
    setPct(0);
  };

  const R = 86, C = 2 * Math.PI * R;
  const ringColor = phase === 'success' ? 'var(--ok)' : phase === 'error' ? 'var(--high)' : 'var(--accent)';

  const status = {
    idle:     { t: 'Mantén presionado el sensor', s: 'Coloca el dedo y no lo sueltes hasta completar la lectura.' },
    scanning: { t: 'Leyendo tu huella…', s: 'Mantén el dedo en su lugar.' },
    success:  { t: 'Identidad verificada', s: 'Bienvenido de nuevo, Francisco Reyes.' },
    error:    { t: 'Lectura incompleta', s: 'Soltaste antes de tiempo. Vuelve a intentarlo.' },
  }[phase];

  if (!open) return null;

  return (
    <Sheet open={open} onClose={onClose} label="Acceso con biometría">
      <div className="relative w-full max-w-[420px] mx-4 bg-surface rounded-3xl shadow-float border border-line p-7 sm:p-9 anim-scale-in text-center">
        <button onClick={onClose} aria-label="Cerrar"
          className="absolute top-4 right-4 grid place-items-center w-10 h-10 rounded-xl text-faint hover:bg-surface-2 hover:text-ink transition-all focus-ring">
          <Icon name="close" size={20} />
        </button>

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6 text-[11px] font-bold tracking-[0.14em] uppercase bg-primary-soft text-primary">
          <Icon name="shield" size={14} /> Acceso biométrico
        </div>

        {/* Sensor */}
        <div className="relative mx-auto grid place-items-center select-none"
          style={{ width: 210, height: 210, touchAction: 'none' }}
          onPointerDown={beginScan}
          onPointerUp={releaseScan}
          onPointerLeave={releaseScan}
          role="button" aria-label="Sensor de huella">

          <svg width="210" height="210" viewBox="0 0 210 210" className="absolute inset-0 -rotate-90">
            <circle cx="105" cy="105" r={R} fill="none" stroke="var(--surface-2)" strokeWidth="7" />
            <circle cx="105" cy="105" r={R} fill="none" stroke={ringColor} strokeWidth="7" strokeLinecap="round"
              strokeDasharray={C}
              strokeDashoffset={phase === 'success' ? 0 : C * (1 - pct)}
              style={{ transition: phase === 'scanning' ? 'none' : 'stroke-dashoffset .4s ease, stroke .3s ease' }} />
          </svg>

          {/* Halo / disco del sensor */}
          <div className="relative grid place-items-center rounded-full transition-colors duration-300"
            style={{
              width: 150, height: 150,
              background: phase === 'success'
                ? 'color-mix(in srgb, var(--ok) 14%, var(--surface))'
                : phase === 'error'
                ? 'var(--high-soft)'
                : 'var(--surface-2)',
              cursor: phase === 'success' ? 'default' : 'pointer',
              boxShadow: phase === 'scanning' ? '0 0 0 6px color-mix(in srgb, var(--accent) 18%, transparent)' : 'none',
            }}>

            {phase === 'success' ? (
              <Icon name="check" size={62} strokeWidth={2.4} style={{ color: 'var(--ok)' }} className="anim-scale-in" />
            ) : (
              <div className="relative" style={{ color: phase === 'error' ? 'var(--high)' : phase === 'scanning' ? 'var(--accent)' : 'var(--text-muted)' }}>
                <Icon name="fingerprint" size={74} strokeWidth={1.5} />
                {/* Línea de barrido durante la lectura */}
                {phase === 'scanning' && (
                  <div className="absolute left-1/2 -translate-x-1/2 rounded-full"
                    style={{
                      width: 78, height: 3, top: `${10 + pct * 56}px`,
                      background: 'var(--accent)',
                      boxShadow: '0 0 10px 1px var(--accent)',
                    }}></div>
                )}
              </div>
            )}
          </div>
        </div>

        <h3 className="font-display font-extrabold text-[21px] tracking-tight text-ink mt-6">{status.t}</h3>
        <p className="text-muted text-[14.5px] mt-1.5 leading-relaxed max-w-[300px] mx-auto">{status.s}</p>

        {phase === 'error' && (
          <button onClick={beginScan}
            className="mt-5 inline-flex items-center gap-2 h-11 px-5 rounded-xl bg-primary text-[color:var(--on-primary)] font-semibold text-[14px] active:scale-95 transition-all focus-ring">
            <Icon name="repeat" size={17} /> Reintentar
          </button>
        )}

        <div className="flex items-center justify-center gap-2 text-faint text-[12px] font-medium mt-7">
          <Icon name="lock" size={14} /> Tus datos biométricos no salen de tu dispositivo
        </div>
      </div>
    </Sheet>
  );
}

/* ============================================================
   CÓDIGO QR — emparejamiento con el teléfono
   ============================================================ */

// Matriz QR-like determinista (con los tres "ojos" en las esquinas)
function makeMatrix(n, seed) {
  const m = Array.from({ length: n }, () => Array(n).fill(false));
  let s = seed;
  const rnd = () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; };
  for (let y = 0; y < n; y++)
    for (let x = 0; x < n; x++)
      m[y][x] = rnd() > 0.52;
  const eye = (oy, ox) => {
    for (let y = 0; y < 7; y++) for (let x = 0; x < 7; x++) {
      const border = x === 0 || x === 6 || y === 0 || y === 6;
      const center = x >= 2 && x <= 4 && y >= 2 && y <= 4;
      m[oy + y][ox + x] = border || center;
    }
    for (let y = -1; y <= 7; y++) for (let x = -1; x <= 7; x++) {
      if ((x === -1 || x === 7 || y === -1 || y === 7) && oy + y >= 0 && oy + y < n && ox + x >= 0 && ox + x < n)
        m[oy + y][ox + x] = false;
    }
  };
  eye(0, 0); eye(0, n - 7); eye(n - 7, 0);
  return m;
}

function QRCanvas({ active }) {
  const N = 25;
  const matrix = useRefAuth(makeMatrix(N, 7919)).current;
  return (
    <div className="relative rounded-2xl bg-white p-3.5" style={{ width: 230, height: 230 }}>
      <div className="grid w-full h-full" style={{ gridTemplateColumns: `repeat(${N}, 1fr)`, gap: 0 }}>
        {matrix.flatMap((row, y) => row.map((on, x) => (
          <div key={`${y}-${x}`} style={{ background: on ? '#0b0b0c' : 'transparent', borderRadius: 1 }}></div>
        )))}
      </div>
      {/* Logo central */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 grid place-items-center rounded-xl bg-white" style={{ width: 46, height: 46 }}>
        <div className="grid place-items-center rounded-lg" style={{ width: 34, height: 34, background: 'var(--accent)' }}>
          <span className="font-display font-extrabold text-[#1a1a1a]" style={{ fontSize: 18 }}>U</span>
        </div>
      </div>
      {/* Línea de escaneo */}
      {active && (
        <div className="absolute left-3.5 right-3.5 rounded-full qr-scan" style={{ height: 3, background: 'var(--accent)', boxShadow: '0 0 12px 2px var(--accent)' }}></div>
      )}
    </div>
  );
}

function QRSheet({ open, onClose, onLogin }) {
  const { Sheet, Icon } = window;
  // 'waiting' | 'scanning' | 'detected' | 'confirmed'
  const [phase, setPhase] = useStateAuth('waiting');
  const [secs, setSecs] = useStateAuth(299);
  const timerRef = useRefAuth(null);

  useEffectAuth(() => {
    if (open) { setPhase('waiting'); setSecs(299); }
  }, [open]);

  // Cuenta regresiva de caducidad del código
  useEffectAuth(() => {
    if (!open || phase !== 'waiting') return;
    timerRef.current = setInterval(() => setSecs((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(timerRef.current);
  }, [open, phase]);

  const mmss = `${String(Math.floor(secs / 60)).padStart(2, '0')}:${String(secs % 60).padStart(2, '0')}`;

  const simulateScan = () => {
    setPhase('scanning');
    setTimeout(() => setPhase('detected'), 1700);
  };
  const confirmOnPhone = () => {
    setPhase('confirmed');
    setTimeout(() => onLogin && onLogin(), 1000);
  };

  if (!open) return null;

  return (
    <Sheet open={open} onClose={onClose} label="Acceso con código QR">
      <div className="relative w-full max-w-[430px] mx-4 bg-surface rounded-3xl shadow-float border border-line p-7 sm:p-9 anim-scale-in text-center">
        <button onClick={onClose} aria-label="Cerrar"
          className="absolute top-4 right-4 grid place-items-center w-10 h-10 rounded-xl text-faint hover:bg-surface-2 hover:text-ink transition-all focus-ring">
          <Icon name="close" size={20} />
        </button>

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6 text-[11px] font-bold tracking-[0.14em] uppercase bg-primary-soft text-primary whitespace-nowrap">
          <Icon name="qr" size={14} /> Vincular con tu teléfono
        </div>

        {/* ---- ESTADOS QR ---- */}
        {(phase === 'waiting' || phase === 'scanning') && (
          <>
            <div className="grid place-items-center">
              <div className="relative" style={{ opacity: phase === 'scanning' ? 1 : 1 }}>
                <QRCanvas active={phase === 'scanning'} />
                {phase === 'scanning' && (
                  <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-ink text-surface text-[12px] font-bold whitespace-nowrap" style={{ background: 'var(--text)', color: 'var(--surface)' }}>
                    Leyendo código…
                  </div>
                )}
              </div>
            </div>

            <h3 className="font-display font-extrabold text-[20px] tracking-tight text-ink mt-7">
              {phase === 'scanning' ? 'Código detectado' : 'Escanea con la app Duoc Unifica'}
            </h3>
            <p className="text-muted text-[14px] mt-1.5 leading-relaxed max-w-[320px] mx-auto">
              Abre la app en tu teléfono, toca <span className="font-semibold text-ink">Escanear QR</span> y apunta a este código.
            </p>

            {phase === 'waiting' && (
              <>
                <div className="inline-flex items-center gap-2 mt-4 px-3 py-1.5 rounded-full bg-surface-2 text-muted text-[12.5px] font-semibold">
                  <Icon name="clock" size={14} /> El código expira en <span className="text-ink tabular-nums">{mmss}</span>
                </div>
                <button onClick={simulateScan}
                  className="mt-6 w-full inline-flex items-center justify-center gap-2 h-12 rounded-xl bg-primary text-[color:var(--on-primary)] font-semibold text-[14.5px] active:scale-[.98] transition-all focus-ring">
                  <Icon name="phone" size={18} /> Simular escaneo desde el teléfono
                </button>
              </>
            )}
          </>
        )}

        {phase === 'detected' && (
          <div className="anim-fade-up">
            {/* Mock de teléfono confirmando */}
            <div className="mx-auto relative rounded-[26px] border-[3px] border-line bg-surface-2 p-3" style={{ width: 168 }}>
              <div className="rounded-[16px] bg-surface border border-line p-4 text-left">
                <div className="flex items-center gap-2 mb-3">
                  <div className="grid place-items-center rounded-lg" style={{ width: 24, height: 24, background: 'var(--accent)' }}>
                    <span className="font-display font-extrabold text-[#1a1a1a] text-[12px]">U</span>
                  </div>
                  <span className="text-[11px] font-bold text-ink">Unifica</span>
                </div>
                <p className="text-[12px] font-semibold text-ink leading-snug">¿Iniciar sesión en este equipo?</p>
                <div className="flex items-center gap-1.5 mt-2 text-[10px] text-faint font-medium">
                  <Icon name="globe" size={11} /> Chrome · Windows
                </div>
                <div className="mt-3 h-7 rounded-lg bg-primary text-[color:var(--on-primary)] grid place-items-center text-[11px] font-bold">Confirmar</div>
              </div>
            </div>

            <h3 className="font-display font-extrabold text-[20px] tracking-tight text-ink mt-6">Confirma en tu teléfono</h3>
            <p className="text-muted text-[14px] mt-1.5 leading-relaxed max-w-[300px] mx-auto">
              Detectamos tu dispositivo. Aprueba el ingreso para continuar.
            </p>
            <button onClick={confirmOnPhone}
              className="mt-6 w-full inline-flex items-center justify-center gap-2 h-12 rounded-xl bg-primary text-[color:var(--on-primary)] font-semibold text-[14.5px] active:scale-[.98] transition-all focus-ring">
              <Icon name="check" size={18} strokeWidth={2.4} /> Aprobar en el teléfono
            </button>
          </div>
        )}

        {phase === 'confirmed' && (
          <div className="anim-fade-up py-4">
            <div className="mx-auto grid place-items-center rounded-full anim-scale-in" style={{ width: 110, height: 110, background: 'color-mix(in srgb, var(--ok) 14%, var(--surface))' }}>
              <Icon name="check" size={56} strokeWidth={2.4} style={{ color: 'var(--ok)' }} />
            </div>
            <h3 className="font-display font-extrabold text-[21px] tracking-tight text-ink mt-6">Dispositivo vinculado</h3>
            <p className="text-muted text-[14.5px] mt-1.5">Ingresando a tu cuenta…</p>
          </div>
        )}

        <div className="flex items-center justify-center gap-2 text-faint text-[12px] font-medium mt-7">
          <Icon name="shield" size={14} /> Conexión cifrada de extremo a extremo
        </div>
      </div>
    </Sheet>
  );
}

window.BiometricSheet = BiometricSheet;
window.QRSheet = QRSheet;
