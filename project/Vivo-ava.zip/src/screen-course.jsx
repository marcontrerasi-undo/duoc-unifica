// src/screen-course.jsx — Detalle de curso re-imaginado → window.CourseScreen
const { useState: useStateCourse } = React;

function buildContent(course) {
  const preset = window.DATA.COURSE_CONTENT[course.id];
  if (preset) return preset;
  return {
    descripcion: `Material y actividades de ${course.nombre}. Accede a recursos, entregas y calificaciones desde un solo lugar.`,
    modulos: [
      { id: 'm0', tipo: 'info', titulo: 'Información de la Asignatura', sub: 'Syllabus y programa', estado: 'Disponible', items: 3 },
      { id: 'm1', tipo: 'experiencia', titulo: 'EA 1 · Fundamentos', sub: '4 recursos · 1 actividad', estado: 'En curso', progreso: 50, items: 5, activo: true },
      { id: 'm2', tipo: 'experiencia', titulo: 'EA 2 · Aplicación', sub: '5 recursos · 1 actividad', estado: 'Disponible', progreso: 0, items: 6 },
    ],
    notas: [
      { eval: 'EA 1', nota: course.promedio, pond: '40%' },
      { eval: 'EA 2', nota: null, pond: '30%' },
      { eval: 'Examen', nota: null, pond: '30%' },
    ],
  };
}

const RESOURCE_ICONS = { info: 'doc', experiencia: 'book', evaluacion: 'award' };
const ESTADO_TONE = { 'Completado': 'ok', 'Revisado': 'ok', 'En curso': 'primary', 'Disponible': 'neutral', 'Bloqueado': 'neutral' };

function CourseScreen({ courseId, initialTab, onBack, onNavigate }) {
  const { Icon, Card, Badge, Button, Progress, CourseGlyph } = window;
  const course = window.DATA.COURSES.find((c) => c.id === courseId) || window.DATA.COURSES[0];
  const content = buildContent(course);
  const [tab, setTab] = useStateCourse(initialTab || 'contenido');
  const [openMod, setOpenMod] = useStateCourse(content.modulos.find((m) => m.activo)?.id || content.modulos[0].id);

  const tabs = [
    { id: 'contenido', label: 'Contenido', icon: 'book' },
    { id: 'asistencia', label: 'Asistencia', icon: 'calendar' },
    { id: 'mensajes', label: 'Mensajes', icon: 'mail' },
    { id: 'notas', label: 'Calificaciones', icon: 'award' },
    { id: 'foro', label: 'Foro y anuncios', icon: 'chat' },
  ];

  const sampleResources = [
    { icon: 'video', t: 'Videocápsula introductoria', d: '8 min · Visto', done: true },
    { icon: 'file', t: 'Lectura: modelos de servicio', d: 'PDF · 12 págs.' },
    { icon: 'link', t: 'Recurso interactivo externo', d: 'Enlace · 15 min' },
    { icon: 'award', t: 'Actividad evaluada EA 2', d: 'Entrega hasta el 10 jun · 23:59', cta: true },
  ];

  return (
    <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
      <button onClick={onBack} className="flex items-center gap-1.5 text-[13.5px] font-bold text-muted hover:text-primary transition-colors mb-4" style={{ minHeight: 40 }}>
        <Icon name="chevronLeft" size={16} /> Volver al inicio
      </button>

      {/* Banner editorial atmosférico (superficie calma + hairline + acento fino) */}
      <div className="anim-fade-up relative rounded-3xl overflow-hidden p-6 sm:p-8 mb-6 bg-surface border border-line">
        <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(var(--border) 1px, transparent 1px)', backgroundSize: '20px 20px', opacity: .55 }}></div>
        <div className="absolute left-0 right-0 top-0 h-[2px]" style={{ background: course.color, opacity: .8 }}></div>
        <div className="relative z-10">
          <div className="flex items-center gap-2.5 mb-3.5 flex-wrap text-faint">
            <span className="flex items-center gap-1.5 text-[11.5px] font-bold tracking-wide uppercase"><span className="w-2 h-2 rounded-full" style={{ background: course.color }}></span> {course.sigla}</span>
            <span className="opacity-50">·</span>
            <span className="text-[11.5px] font-bold tracking-wide uppercase">Sección {course.seccion}</span>
            <span className="opacity-50">·</span>
            <span className="text-[11.5px] font-bold tracking-wide uppercase">{course.proxima}</span>
          </div>
          <h1 className="font-display font-medium text-[clamp(1.7rem,4vw,2.5rem)] leading-[1.1] tracking-tight max-w-2xl text-ink">{course.nombre}</h1>
          <p className="text-muted text-[14.5px] mt-2.5 max-w-xl leading-relaxed">{content.descripcion}</p>
          <div className="flex items-center gap-5 mt-6 flex-wrap pt-5 border-t border-line">
            <div className="flex items-center gap-2 text-[13.5px] font-semibold text-ink"><Icon name="user" size={16} className="text-faint" /> {course.docente}</div>
            <div className="flex items-center gap-3 flex-1 min-w-[180px] max-w-xs">
              <span className="text-[12.5px] font-bold whitespace-nowrap text-muted">{course.progreso}% completado</span>
              <div className="flex-1"><Progress value={course.progreso} color="var(--ok)" track="var(--surface-2)" height={6} /></div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 rounded-2xl bg-surface border border-line shadow-card mb-6 overflow-x-auto">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 h-11 rounded-xl text-[14px] font-semibold whitespace-nowrap transition-all ${tab === t.id ? 'bg-primary text-[color:var(--on-primary)] shadow-card' : 'text-muted hover:bg-surface-2 hover:text-ink'}`} style={{ minHeight: 44 }}>
            <Icon name={t.icon} size={17} /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'contenido' && (
        <div className="grid lg:grid-cols-3 gap-6 anim-fade-in">
          <div className="lg:col-span-2 space-y-3">
            {content.modulos.map((m, i) => {
              const open = openMod === m.id;
              const locked = m.estado === 'Bloqueado';
              return (
                <div key={m.id} className={`bg-surface border rounded-2xl shadow-card overflow-hidden transition-all anim-fade-up ${open ? 'border-primary/40' : 'border-line'}`} style={{ animationDelay: `${i * .05}s` }}>
                  <button onClick={() => !locked && setOpenMod(open ? null : m.id)} disabled={locked}
                    className={`w-full flex items-center gap-3.5 p-4 text-left transition-colors ${locked ? 'opacity-60 cursor-not-allowed' : 'hover:bg-surface-2'}`}>
                    <div className="grid place-items-center rounded-xl shrink-0" style={{ width: 42, height: 42, background: open ? 'var(--primary)' : 'var(--primary-soft)' }}>
                      <Icon name={locked ? 'lock' : RESOURCE_ICONS[m.tipo]} size={19} className={open ? 'text-[color:var(--on-primary)]' : 'text-primary'} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-display font-bold text-ink text-[15px] leading-snug">{m.titulo}</h3>
                        <Badge tone={ESTADO_TONE[m.estado]}>{m.estado}</Badge>
                      </div>
                      <p className="text-faint text-[12.5px] mt-0.5">{m.sub}</p>
                      {typeof m.progreso === 'number' && m.progreso > 0 && (
                        <div className="mt-2 max-w-[200px]"><Progress value={m.progreso} color="var(--ok)" height={5} /></div>
                      )}
                    </div>
                    {!locked && <Icon name="chevronDown" size={18} className={`text-faint shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />}
                  </button>
                  {open && !locked && (
                    <div className="px-4 pb-4 anim-fade-in">
                      <div className="space-y-2 pt-1">
                        {sampleResources.map((r, idx) => (
                          <div key={idx} className={`flex items-center gap-3 p-3 rounded-xl border transition-all hover:border-primary/40 cursor-pointer group ${r.cta ? 'bg-medium-soft border-transparent' : 'bg-surface-2 border-line'}`}>
                            <div className="grid place-items-center rounded-lg bg-surface shrink-0" style={{ width: 34, height: 34 }}>
                              <Icon name={r.icon} size={16} className={r.cta ? 'text-medium' : 'text-primary'} />
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="text-ink font-semibold text-[13.5px] leading-snug">{r.t}</p>
                              <p className="text-faint text-[12px]">{r.d}</p>
                            </div>
                            {r.done ? <Icon name="checkCircle" size={18} className="text-[var(--ok)]" /> : r.cta ? <Button size="sm" variant="accent">Entregar</Button> : <Icon name="chevronRight" size={16} className="text-faint group-hover:translate-x-0.5 transition-transform" />}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          {/* Lateral del curso */}
          <div className="space-y-4">
            <Card>
              <h3 className="font-display font-bold text-ink text-[15px] mb-3">Accesos del curso</h3>
              <div className="space-y-1.5">
                {[{ i: 'doc', t: 'Syllabus' }, { i: 'calendar', t: 'Mi asistencia' }, { i: 'users', t: 'Compañeros y grupos' }, { i: 'chat', t: 'Foro de dudas' }, { i: 'award', t: 'Mis calificaciones' }].map((a) => (
                  <button key={a.t} onClick={() => { if (a.t.includes('calific')) setTab('notas'); else if (a.t.includes('asistencia')) setTab('asistencia'); }} className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-surface-2 transition-colors text-left" style={{ minHeight: 44 }}>
                    <Icon name={a.i} size={18} className="text-primary" />
                    <span className="text-ink font-semibold text-[13.5px] flex-1">{a.t}</span>
                    <Icon name="chevronRight" size={16} className="text-faint" />
                  </button>
                ))}
              </div>
            </Card>
            <Card className="bg-primary-soft border-transparent">
              <div className="flex items-center gap-2 mb-1.5"><Icon name="support" size={18} className="text-primary" /><h3 className="font-display font-bold text-ink text-[15px]">¿Trámite del ramo?</h3></div>
              <p className="text-muted text-[13px] leading-relaxed">Solicita certificados, justifica inasistencias o revisa tu asistencia sin cambiar de plataforma.</p>
              <Button size="sm" variant="primary" full className="mt-3" iconRight="arrowRight" onClick={() => onNavigate('ayuda')}>Ir a trámites</Button>
            </Card>
          </div>
        </div>
      )}

      {tab === 'mensajes' && <MessagesTab course={course} />}

      {tab === 'asistencia' && <AttendanceTab course={course} />}

      {tab === 'notas' && (
        <Card className="anim-fade-in" pad={false}>
          <div className="p-5 border-b border-line flex items-center justify-between flex-wrap gap-2">
            <h3 className="font-display font-bold text-ink text-[16px]">Calificaciones</h3>
            <div className="flex items-center gap-2 text-[13px]"><span className="text-muted font-medium">Promedio actual</span><span className="font-display font-extrabold text-[20px]" style={{ color: course.color }}>{course.promedio?.toFixed(1)}</span></div>
          </div>
          <div className="divide-y divide-[var(--border)]">
            {content.notas.map((n, idx) => (
              <div key={idx} className="flex items-center gap-4 p-4">
                <div className="grid place-items-center rounded-xl shrink-0" style={{ width: 40, height: 40, background: n.nota ? 'color-mix(in srgb, var(--ok) 12%, transparent)' : 'var(--surface-2)' }}>
                  <Icon name={n.nota ? 'check' : 'clock'} size={18} style={{ color: n.nota ? 'var(--ok)' : 'var(--text-faint)' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-ink font-semibold text-[14px]">{n.eval}</p>
                  <p className="text-faint text-[12px]">Ponderación {n.pond}</p>
                </div>
                {n.nota ? <span className="font-display font-extrabold text-[22px] text-ink tabular-nums">{n.nota.toFixed(1)}</span> : <Badge tone="neutral">Pendiente</Badge>}
              </div>
            ))}
          </div>
        </Card>
      )}

      {tab === 'foro' && (
        <div className="anim-fade-in space-y-3">
          {[{ a: 'Rodrigo Maldonado', r: 'Docente', t: 'Material complementario EA 2', d: 'Recuerden revisar la lectura sobre modelos IaaS/PaaS antes de la sesión del miércoles.', time: 'Hace 2 h', pin: true },
            { a: 'Valentina Soto', r: 'Estudiante', t: '¿Dudas sobre la entrega?', d: '¿La actividad evaluada se entrega individual o en grupo?', time: 'Ayer' }].map((p, i) => (
            <Card key={i} className="anim-fade-up" style={{ animationDelay: `${i * .05}s` }}>
              <div className="flex items-start gap-3">
                <window.Avatar iniciales={p.a.split(' ').map((x) => x[0]).join('')} size={42} color={p.r === 'Docente' ? course.color : 'var(--low)'} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-ink text-[14px]">{p.a}</span>
                    <Badge tone={p.r === 'Docente' ? 'primary' : 'neutral'}>{p.r}</Badge>
                    {p.pin && <Badge tone="accent" icon="bookmark">Fijado</Badge>}
                    <span className="text-faint text-[12px]">· {p.time}</span>
                  </div>
                  <h4 className="font-display font-bold text-ink text-[15px] mt-1">{p.t}</h4>
                  <p className="text-muted text-[13.5px] leading-relaxed mt-1">{p.d}</p>
                  <div className="flex items-center gap-4 mt-3">
                    <button className="text-[12.5px] font-bold text-muted hover:text-primary flex items-center gap-1.5"><Icon name="chat" size={15} /> Responder</button>
                    <button className="text-[12.5px] font-bold text-muted hover:text-primary flex items-center gap-1.5"><Icon name="check" size={15} /> Útil</button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

window.CourseScreen = CourseScreen;

// ---- Mensajes del curso: distinción privado (docente→tú) vs al curso completo ----
function initials(name) {
  return name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
}

function buildMessages(course) {
  const doc = course.docente;
  return [
    {
      id: 't0', tipo: 'privado', con: doc, tiempo: 'Hace 3 h', noLeido: true,
      preview: 'Hola Francisco, recuerda subir tu avance del proyecto de despliegue antes del viernes…',
      mensajes: [
        { rol: 'docente', autor: doc, fecha: 'Hoy', hora: '08:15', texto: 'Hola Francisco 👋 Recuerda subir tu avance del proyecto de despliegue antes del viernes a las 23:59. Cualquier duda me escribes por aquí.' },
      ],
    },
    {
      id: 't1', tipo: 'privado', con: doc, tiempo: 'Hace 2 días',
      preview: 'Retroalimentación EA 2 · Estado general: Logrado. Revisa el detalle por criterio.',
      mensajes: [
        { rol: 'docente', autor: doc, fecha: '27 may', hora: '10:07', titulo: 'Retroalimentación · Experiencia de Aprendizaje 2', estado: 'Logrado', tabla: [
          { criterio: 'Variables y contadores', estado: 'Logrado', detalle: 'Declara correctamente las variables de cantidad, código y contadores finales.' },
          { criterio: 'Lectura de registros', estado: 'Logrado', detalle: 'Valida que la cantidad de registros sea mayor a cero antes de iniciar.' },
          { criterio: 'Validación de datos', estado: 'Por mejorar', detalle: 'Refuerza el control de entradas inválidas para la próxima entrega.' },
        ], texto: '¡Buen trabajo en general! Sigue reforzando la validación de datos para la EA 3.' },
        { rol: 'tu', autor: 'Tú', fecha: '27 may', hora: '18:22', texto: 'Muchas gracias profe, lo tendré presente para la siguiente experiencia. 🙌' },
      ],
    },
    {
      id: 't2', tipo: 'curso', con: doc, tiempo: 'Hace 1 semana',
      preview: 'Estimados. Ya está disponible en AVA el calendario de evaluaciones del semestre.',
      mensajes: [
        { rol: 'docente', autor: doc, fecha: '20 mar', hora: '09:40', texto: 'Estimados, por una emergencia debo reagendar la clase del lunes. Les informaré a la brevedad cómo coordinamos la recuperación. Agradezco su comprensión.\n\nEl lunes desarrollaremos la solución de las Guías 1 y 2 de diagramas de flujo. Saludos cordiales.' },
        { rol: 'estudiante', autor: 'Jhon Guems', fecha: '21 mar', hora: '10:01', texto: '¡Recibido! Muchas gracias profe.' },
        { rol: 'docente', autor: doc, fecha: '23 mar', hora: '10:16', texto: 'Estimados. Ya está disponible en AVA el calendario de evaluaciones, para que planifiquen su semestre acorde. Saludos cordiales.', adjunto: { nombre: 'calendario_evaluaciones.pdf', tipo: 'PDF · 240 KB' } },
      ],
    },
  ];
}

const TIPO_MSG = {
  privado: { label: 'Privado', tone: 'accent', icon: 'lock', para: 'Solo para ti', corto: 'Privados' },
  curso: { label: 'Al curso', tone: 'primary', icon: 'users', para: 'Para todo el curso', corto: 'Al curso' },
};

function MessagesTab({ course }) {
  const { Icon, Badge, Avatar, Button } = window;
  const threads = buildMessages(course);
  const [openId, setOpenId] = useStateCourse(null);
  const [filter, setFilter] = useStateCourse('todos');
  const [draft, setDraft] = useStateCourse('');

  const open = threads.find((t) => t.id === openId);

  // ---------- Vista de conversación ----------
  if (open) {
    const meta = TIPO_MSG[open.tipo];
    let lastFecha = null;
    return (
      <div className="anim-fade-in">
        <div className="bg-surface border border-line rounded-2xl shadow-card overflow-hidden flex flex-col" style={{ height: 'min(620px, 72vh)' }}>
          {/* Encabezado del hilo */}
          <div className="flex items-center gap-3 px-4 sm:px-5 h-[64px] border-b border-line shrink-0">
            <button onClick={() => setOpenId(null)} aria-label="Volver" className="grid place-items-center rounded-xl text-muted hover:bg-surface-2 shrink-0" style={{ width: 38, height: 38 }}><Icon name="chevronLeft" size={19} /></button>
            <Avatar iniciales={initials(open.con)} color={course.color} size={40} />
            <div className="min-w-0 flex-1">
              <div className="font-display font-bold text-ink text-[15px] truncate">{open.tipo === 'curso' ? 'Todos los estudiantes' : open.con}</div>
              <div className="text-faint text-[12px] truncate">{open.tipo === 'curso' ? `${open.con} · ${course.nombre}` : open.con}</div>
            </div>
            <Badge tone={meta.tone} icon={meta.icon}>{meta.label}</Badge>
          </div>

          {/* Mensajes */}
          <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-5 space-y-1" style={{ background: 'var(--surface-2)' }}>
            {open.mensajes.map((m, idx) => {
              const showDate = m.fecha !== lastFecha; lastFecha = m.fecha;
              const mine = m.rol === 'tu';
              return (
                <div key={idx}>
                  {showDate && (
                    <div className="flex justify-center my-4"><span className="px-3 py-1 rounded-full bg-surface border border-line text-faint text-[11.5px] font-bold">{m.fecha}</span></div>
                  )}
                  <div className={`flex items-start gap-2.5 ${mine ? 'flex-row-reverse' : ''}`}>
                    {!mine && <Avatar iniciales={initials(m.autor)} color={m.rol === 'docente' ? course.color : 'var(--low)'} size={34} />}
                    <div className={`max-w-[80%] ${mine ? 'items-end' : 'items-start'} flex flex-col`}>
                      <div className={`flex items-center gap-2 mb-1 px-1 ${mine ? 'flex-row-reverse' : ''}`}>
                        <span className="text-[12px] font-bold text-ink">{mine ? 'Tú' : m.autor}</span>
                        {m.rol === 'docente' && <Badge tone="primary">Docente</Badge>}
                        <span className="text-faint text-[11px]">{m.hora}</span>
                      </div>
                      <div className={`rounded-2xl px-4 py-3 text-[13.5px] leading-relaxed shadow-card ${mine ? 'bg-primary text-[color:var(--on-primary)] rounded-tr-md' : 'bg-surface text-ink border border-line rounded-tl-md'}`}>
                        {m.titulo && (
                          <div className="mb-2">
                            <p className="font-display font-bold text-[14.5px] leading-snug">{m.titulo}</p>
                            {m.estado && <span className="inline-flex items-center gap-1 mt-1.5 px-2 py-0.5 rounded-full text-[11px] font-bold whitespace-nowrap" style={{ background: 'color-mix(in srgb, var(--ok) 14%, transparent)', color: 'var(--ok)' }}><Icon name="check" size={12} strokeWidth={2.4} /> Estado general: {m.estado}</span>}
                          </div>
                        )}
                        {m.tabla && (
                          <div className="my-2 rounded-xl overflow-hidden border border-line bg-surface">
                            {m.tabla.map((row, r) => (
                              <div key={r} className={`grid grid-cols-[1fr_auto] gap-x-3 gap-y-1 p-2.5 text-[12.5px] ${r > 0 ? 'border-t border-line' : ''}`}>
                                <span className="font-semibold text-ink">{row.criterio}</span>
                                <span className="font-bold text-[11.5px] whitespace-nowrap" style={{ color: row.estado === 'Logrado' ? 'var(--ok)' : 'var(--medium)' }}>{row.estado}</span>
                                <span className="text-muted col-span-2 leading-snug">{row.detalle}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {m.texto && <p className="whitespace-pre-line">{m.texto}</p>}
                        {m.adjunto && (
                          <div className={`flex items-center gap-2.5 mt-2.5 p-2.5 rounded-xl ${mine ? 'bg-[color-mix(in_srgb,var(--on-primary)_12%,transparent)]' : 'bg-surface-2'}`}>
                            <Icon name="file" size={18} className={mine ? '' : 'text-primary'} />
                            <div className="min-w-0"><p className="font-semibold text-[12.5px] truncate">{m.adjunto.nombre}</p><p className="text-[11px] opacity-75">{m.adjunto.tipo}</p></div>
                            <Icon name="download" size={16} className="ml-auto opacity-75" />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Redactar */}
          <div className="border-t border-line p-3 shrink-0 bg-surface">
            <div className="flex items-end gap-2">
              <textarea value={draft} onChange={(e) => setDraft(e.target.value)} rows={1} placeholder={open.tipo === 'curso' ? 'Responder a todo el curso…' : 'Escribe un mensaje…'} className="flex-1 resize-none bg-surface-2 border border-line rounded-xl px-4 py-3 text-[13.5px] text-ink outline-none focus:border-primary transition-colors max-h-32" style={{ minHeight: 46 }} />
              <button onClick={() => setDraft('')} disabled={!draft.trim()} aria-label="Enviar" className="grid place-items-center rounded-xl bg-primary text-[color:var(--on-primary)] disabled:opacity-40 transition-opacity shrink-0" style={{ width: 46, height: 46 }}><Icon name="arrowRight" size={20} /></button>
            </div>
            <label className="flex items-center gap-2 mt-2 ml-1 text-[12px] text-faint font-medium cursor-pointer select-none">
              <span className="w-4 h-4 rounded border border-line bg-surface-2"></span> Enviar una copia a mi correo institucional
            </label>
          </div>
        </div>
      </div>
    );
  }

  // ---------- Bandeja de entrada ----------
  const filtered = threads.filter((t) => (filter === 'todos' ? true : t.tipo === filter));
  const noLeidos = threads.filter((t) => t.noLeido).length;
  return (
    <div className="anim-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="font-display font-bold text-ink text-[18px] flex items-center gap-2"><Icon name="mail" size={19} className="text-primary" /> Mensajes del curso</h3>
          <p className="text-faint text-[12.5px] mt-0.5">Comunicación directa con tu docente{noLeidos > 0 ? ` · ${noLeidos} sin leer` : ''}</p>
        </div>
        <Button size="sm" variant="primary" icon="plus">Nuevo mensaje</Button>
      </div>

      {/* Filtro: distinción privado / al curso */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-surface-2 w-fit mb-4">
        {[{ id: 'todos', label: 'Todos' }, { id: 'privado', label: 'Privados' }, { id: 'curso', label: 'Al curso' }].map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)} className={`px-3.5 h-9 rounded-lg text-[13px] font-bold transition-all flex items-center gap-1.5 ${filter === f.id ? 'bg-surface text-ink shadow-card' : 'text-faint hover:text-muted'}`}>
            {f.id !== 'todos' && <Icon name={TIPO_MSG[f.id].icon} size={14} />} {f.label}
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-2.5">
        {filtered.map((t) => {
          const meta = TIPO_MSG[t.tipo];
          return (
            <button key={t.id} onClick={() => setOpenId(t.id)} className="text-left bg-surface border border-line rounded-2xl p-4 shadow-card hover:shadow-float hover:border-primary/40 transition-all duration-300 group">
              <div className="flex items-start gap-3.5">
                <div className="relative shrink-0">
                  <Avatar iniciales={initials(t.con)} color={course.color} size={46} />
                  <span className="absolute -bottom-0.5 -right-0.5 grid place-items-center rounded-full ring-2 ring-surface" style={{ width: 20, height: 20, background: `var(--${meta.tone === 'accent' ? 'accent' : 'primary'})`, color: meta.tone === 'accent' ? 'var(--accent-ink)' : 'var(--on-primary)' }}><Icon name={meta.icon} size={11} strokeWidth={2.4} /></span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-display font-bold text-ink text-[14.5px] truncate group-hover:text-primary transition-colors">{t.con}</span>
                    <span className="text-faint text-[11.5px] font-medium shrink-0">{t.tiempo}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <Badge tone={meta.tone} icon={meta.icon}>{meta.label}</Badge>
                    <span className="text-faint text-[12px] font-medium">{meta.para}</span>
                    {t.noLeido && <span className="ml-auto w-2.5 h-2.5 rounded-full bg-high shrink-0"></span>}
                  </div>
                  <p className={`text-[13px] leading-snug mt-1.5 line-clamp-1 ${t.noLeido ? 'text-ink font-semibold' : 'text-muted'}`}>{t.preview}</p>
                </div>
              </div>
            </button>
          );
        })}
        {filtered.length === 0 && (
          <div className="text-center py-14 bg-surface border border-line rounded-2xl">
            <Icon name="mail" size={30} className="text-faint mx-auto" />
            <p className="text-muted text-[14px] font-medium mt-2">No hay mensajes en esta categoría.</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ---- Asistencia del curso: métrica independiente del progreso académico ----
const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

function computeAttendance(course) {
  const a = course.asistencia || { minimo: 75, total: 0, asistidas: 0, inasistencias: 0 };
  const realizadas = a.asistidas + a.inasistencias;
  const restantes = Math.max(0, a.total - realizadas);
  const maxFaltas = Math.floor(a.total * (1 - a.minimo / 100));
  const puedeFaltar = Math.max(0, maxFaltas - a.inasistencias);
  const pct = realizadas > 0 ? Math.round((a.asistidas / realizadas) * 100) : 100;
  const enRiesgo = puedeFaltar <= 1 || pct < a.minimo;
  return { ...a, realizadas, restantes, maxFaltas, puedeFaltar, pct, enRiesgo };
}

function buildSessions(course, m) {
  const sesiones = [];
  // Marca de inasistencias: distribuidas, nunca en la sesión más reciente
  const ausentes = new Set();
  let placed = 0, idx = 1;
  while (placed < m.inasistencias && idx < m.realizadas) { ausentes.add(idx); placed++; idx += 2; }
  let idx2 = 2;
  while (placed < m.inasistencias) { if (!ausentes.has(idx2)) { ausentes.add(idx2); placed++; } idx2++; }

  const base = new Date(2026, 5, 11); // referencia: clase más reciente
  for (let i = 0; i < m.realizadas; i++) {
    const d = new Date(base.getTime() - i * 7 * 86400000);
    sesiones.push({
      n: m.realizadas - i,
      fecha: `${d.getDate()} ${MESES[d.getMonth()]}`,
      ausente: ausentes.has(i),
    });
  }
  return sesiones;
}

function AttendanceTab({ course }) {
  const { Icon, Card, Badge, Progress } = window;
  const m = computeAttendance(course);
  const sesiones = buildSessions(course, m);

  const tono = m.enRiesgo ? 'var(--high)' : m.pct < m.minimo + 8 ? 'var(--medium)' : 'var(--ok)';
  const R = 58, C = 2 * Math.PI * R;

  const tiles = [
    { label: 'Clases asistidas', val: m.asistidas, sub: `de ${m.realizadas} realizadas`, icon: 'checkCircle', color: 'var(--ok)' },
    { label: 'Inasistencias', val: m.inasistencias, sub: m.inasistencias === 1 ? 'clase no asistida' : 'clases no asistidas', icon: 'close', color: 'var(--high)' },
    { label: 'Total del semestre', val: m.total, sub: `${m.restantes} clases por dictar`, icon: 'calendar', color: 'var(--text-muted)' },
    { label: 'Puedes faltar', val: m.puedeFaltar, sub: `de ${m.maxFaltas} permitidas`, icon: 'shield', color: m.enRiesgo ? 'var(--high)' : 'var(--primary)' },
  ];

  return (
    <div className="anim-fade-in space-y-5">
      {/* Resumen con anillo */}
      <Card pad={false} className="overflow-hidden">
        <div className="flex flex-col sm:grid items-center gap-6 p-6" style={{ gridTemplateColumns: '150px minmax(0, 1fr)' }}>
          <div className="relative grid place-items-center shrink-0" style={{ width: 150, height: 150 }}>
            <svg width="150" height="150" viewBox="0 0 150 150" className="absolute inset-0 -rotate-90">
              <circle cx="75" cy="75" r={R} fill="none" stroke="var(--surface-2)" strokeWidth="11" />
              <circle cx="75" cy="75" r={R} fill="none" stroke={tono} strokeWidth="11" strokeLinecap="round"
                strokeDasharray={C} strokeDashoffset={C * (1 - m.pct / 100)} style={{ transition: 'stroke-dashoffset .9s cubic-bezier(.22,1,.36,1)' }} />
            </svg>
            <div className="text-center">
              <div className="font-display font-extrabold tracking-tight tabular-nums leading-none" style={{ fontSize: 38, color: tono }}>{m.pct}%</div>
              <div className="text-faint text-[11.5px] font-bold mt-1">asistencia</div>
            </div>
          </div>
          <div className="flex-1 min-w-0 w-full text-center sm:text-left">
            <div className="flex items-center gap-2.5 justify-center sm:justify-start flex-wrap">
              <h3 className="font-display font-bold text-ink text-[18px]">Tu asistencia</h3>
              <Badge tone={m.enRiesgo ? 'high' : 'ok'} icon={m.enRiesgo ? 'flame' : 'check'}>{m.enRiesgo ? 'En riesgo' : 'Al día'}</Badge>
            </div>
            <p className="text-muted text-[13.5px] mt-1.5 leading-relaxed max-w-md">
              Métrica independiente de tu progreso académico. Para aprobar debes mantener al menos un <span className="font-bold text-ink">{m.minimo}%</span> de asistencia en el semestre.
            </p>
            <div className="mt-4 max-w-md mx-auto sm:mx-0">
              <div className="flex items-center justify-between text-[12px] font-semibold mb-1.5">
                <span className="text-faint">Mínimo requerido {m.minimo}%</span>
                <span className="tabular-nums" style={{ color: tono }}>{m.pct}% actual</span>
              </div>
              <div className="relative">
                <Progress value={m.pct} color={tono} track="var(--surface-2)" height={9} />
                <span className="absolute top-1/2 -translate-y-1/2 w-0.5 h-4 bg-ink rounded-full" style={{ left: `${m.minimo}%`, opacity: .55 }} title={`Mínimo ${m.minimo}%`}></span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Alerta de riesgo */}
      {m.enRiesgo && (
        <div className="flex items-start gap-3.5 p-4 rounded-2xl bg-high-soft border border-[color-mix(in_srgb,var(--high)_22%,transparent)] anim-fade-up">
          <div className="grid place-items-center rounded-xl shrink-0" style={{ width: 38, height: 38, background: 'color-mix(in srgb, var(--high) 16%, transparent)' }}>
            <Icon name="flame" size={19} style={{ color: 'var(--high)' }} />
          </div>
          <div className="min-w-0">
            <p className="font-bold text-ink text-[14.5px]">Asistencia en riesgo</p>
            <p className="text-muted text-[13px] leading-relaxed mt-0.5">
              {m.puedeFaltar === 0
                ? `Alcanzaste el máximo de ${m.maxFaltas} inasistencias permitidas. Una falta más podría reprobarte por asistencia.`
                : `Solo puedes faltar a ${m.puedeFaltar} clase${m.puedeFaltar === 1 ? '' : 's'} más para no bajar del ${m.minimo}% requerido. Si tienes una inasistencia justificada, regístrala en trámites.`}
            </p>
          </div>
        </div>
      )}

      {/* Métricas */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {tiles.map((tile) => (
          <Card key={tile.label} className="text-center sm:text-left">
            <div className="flex items-center gap-2 mb-2">
              <div className="grid place-items-center rounded-lg shrink-0" style={{ width: 30, height: 30, background: `color-mix(in srgb, ${tile.color} 14%, transparent)` }}>
                <Icon name={tile.icon} size={16} style={{ color: tile.color }} />
              </div>
              <span className="text-faint text-[12px] font-bold leading-tight">{tile.label}</span>
            </div>
            <div className="font-display font-extrabold text-ink tabular-nums leading-none" style={{ fontSize: 30 }}>{tile.val}</div>
            <p className="text-faint text-[12px] mt-1">{tile.sub}</p>
          </Card>
        ))}
      </div>

      {/* Detalle de clases */}
      <Card pad={false}>
        <div className="p-5 border-b border-line flex items-center justify-between flex-wrap gap-2">
          <h3 className="font-display font-bold text-ink text-[16px]">Detalle de clases</h3>
          <div className="flex items-center gap-3 text-[12px] font-semibold">
            <span className="flex items-center gap-1.5 text-muted"><span className="w-2.5 h-2.5 rounded-full" style={{ background: 'var(--ok)' }}></span> Presente</span>
            <span className="flex items-center gap-1.5 text-muted"><span className="w-2.5 h-2.5 rounded-full" style={{ background: 'var(--high)' }}></span> Ausente</span>
          </div>
        </div>
        <div className="divide-y divide-[var(--border)] max-h-[420px] overflow-y-auto">
          {sesiones.map((s) => (
            <div key={s.n} className="flex items-center gap-4 px-5 py-3.5">
              <div className="grid place-items-center rounded-xl shrink-0" style={{ width: 38, height: 38, background: s.ausente ? 'var(--high-soft)' : 'color-mix(in srgb, var(--ok) 12%, transparent)' }}>
                <Icon name={s.ausente ? 'close' : 'check'} size={18} strokeWidth={2.4} style={{ color: s.ausente ? 'var(--high)' : 'var(--ok)' }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-ink font-semibold text-[14px]">Sesión {String(s.n).padStart(2, '0')}</p>
                <p className="text-faint text-[12px]">{s.fecha} · {course.proxima.split(' · ')[1] || 'Presencial'}</p>
              </div>
              <Badge tone={s.ausente ? 'high' : 'ok'}>{s.ausente ? 'Ausente' : 'Presente'}</Badge>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

window.AttendanceTab = AttendanceTab;
